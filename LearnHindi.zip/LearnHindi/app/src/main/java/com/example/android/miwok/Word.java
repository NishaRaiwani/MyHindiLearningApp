package com.example.android.miwok;

/**
 * Created by anshu on 7/18/2017.
 */

public class Word {
    // String Variable for Miwok Translation
    private String mDefaultTranslation;
    //  String Variable for Miwok Translation
    private String mMiwokTranslation;
    // Variable to store image resource id
    private int imageId = NO_IMAGE_PROVIDED;
    /** Constant value that represents no image was provided for this word */
    private static final int NO_IMAGE_PROVIDED = -1;
    // int to store media player resource id
    private int soundId;
    // Constructor of Word class to intialie object
    public Word(String mDefTrans, String mMiwTrans, int musicId) {
        mDefaultTranslation = mDefTrans;
        mMiwokTranslation = mMiwTrans;
        soundId = musicId;
    }
    /**
    * Constructor for Activities for images
     * */

    public Word(String mDefTrans, String mMiwTrans, int imgResId, int musicId) {
        mDefaultTranslation = mDefTrans;
        mMiwokTranslation = mMiwTrans;
        imageId = imgResId;
        soundId = musicId;
    }
/* method for retuning deafault translation */

    public String getDefaultTranslation() {
        return mDefaultTranslation;
    }

    /* method for retuning Miwok translation */
    public String getMiwokTranslation() {
        return mMiwokTranslation;
    }
    /*
       Method for getting Imgae through image resource id
     */
    public int getImageResourceId(){ return imageId;}

    /**
         * Returns whether or not there is an image for this word.
          */
    public boolean hasImage() {return imageId != NO_IMAGE_PROVIDED;}

    // method for return media file
    public int getMusicResourceId(){ return soundId;}
}

