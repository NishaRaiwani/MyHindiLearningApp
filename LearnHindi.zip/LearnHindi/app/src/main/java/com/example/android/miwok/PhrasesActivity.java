package com.example.android.miwok;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class PhrasesActivity extends AppCompatActivity {
MediaPlayer mMediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phrases);

        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("Where are you going?" , "Aap Kanhaa Jaa Rahe Ho?",R.raw.pharese_whrugoing));
        words.add(new Word("What is your name?" , "Aapka naam kya hai?",R.raw.phrases_whatname));
        words.add(new Word("My name is..." , "Mera naam ... hai.",R.raw.phrases_myname));
        words.add(new Word("How are you feeling?" , "Aap kaisa mehsoos kar rahe hain?",R.raw.phrases_feeling));
        words.add(new Word("I’m feeling good." , "Main acha mehsoos kar raha/rahi hun.",R.raw.phrases_ansfeeling));
        words.add(new Word("Are you coming?" , "Kya aap aa rahe ho?",R.raw.phrases_rucoming));
        words.add(new Word("I’m coming." , "Main aa raha/rahi hun.",R.raw.phrases_mcoming));
        words.add(new Word("Let’s go." , "Chalo chalen.",R.raw.phrases_letsgo));
        words.add(new Word("Come here." , "Yanhaa aaiye.",R.raw.phrases_comehere));
        words.add(new Word("Yes, I’m coming." , "Haan, Main aa raha/rahi hun.",R.raw.phrases_yesmcoming));

        WordAdapter itemsAdapter = new WordAdapter(this, words, R.color.category_phrases);

        ListView listView = (ListView) findViewById(R.id.list_phrases);

        listView.setAdapter(itemsAdapter);
        //Calling onitemlistener for media file
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                mMediaPlayer = MediaPlayer.create(PhrasesActivity.this , words.get(position).getMusicResourceId());
                mMediaPlayer.start();

            }
        });
    }

}
