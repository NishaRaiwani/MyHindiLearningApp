package com.example.android.miwok;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class FamilyActivity extends AppCompatActivity {
MediaPlayer mMediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family);

        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("Mother" , "Maa",R.drawable.family_mother,R.raw.family_mother));
        words.add(new Word("Father" , "Pita ji / Babu Ji",R.drawable.family_father,R.raw.family_father));
        words.add(new Word("Son" , "Beta / Putra",R.drawable.family_son,R.raw.family_older_brother));
        words.add(new Word("Daughter" , "Beti / Putri",R.drawable.family_daughter,R.raw.family_older_sister));
        words.add(new Word("Elder Brother" , "Bhaiyaa",R.drawable.family_older_brother,R.raw.family_older_brother));
        words.add(new Word("Younger Brother" , "Anuj bhai",R.drawable.family_younger_brother,R.raw.family_younger_brother));
        words.add(new Word("Elder Sister" , "Didi",R.drawable.family_older_sister,R.raw.family_older_sister));
        words.add(new Word("Younger Sister" , "Choti Behan",R.drawable.family_younger_sister,R.raw.family_younger_sister));
        words.add(new Word("Grand Mother" , "Dadi Ji / Nani Ji",R.drawable.family_grandmother,R.raw.family_grandmother));
        words.add(new Word("Grand Father" , "Dada ji / Nana Ji",R.drawable.family_grandfather,R.raw.family_grandfather));

        WordAdapter itemsAdapter = new WordAdapter(this, words, R.color.category_family);

        ListView listView = (ListView) findViewById(R.id.list_family);

        listView.setAdapter(itemsAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                mMediaPlayer = MediaPlayer.create(FamilyActivity.this , words.get(position).getMusicResourceId());
                mMediaPlayer.start();

            }
        });

    }

}
